package com.example.springtemplate.daos;

import com.example.springtemplate.models.Pass;
import com.example.springtemplate.repositories.PassRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class PassOrmDao {
    @Autowired
    PassRepository passRepository;

    @GetMapping("/api/create/pass/{des}/{pri}/{sd}/{ed}/{fpk}/{fp}")
    public Pass createPass(
            @PathVariable("des") String description,
            @PathVariable("pri") Integer price,
            @PathVariable("sd") String startDate,
            @PathVariable("ed") String endDate,
            @PathVariable("fpk") Boolean foodPack,
            @PathVariable("fp") Boolean fastPass) {
        Pass pass = new Pass(description, price, startDate, endDate, foodPack, fastPass, null, null);
        return passRepository.save(pass);
    }

    @GetMapping("/api/find/passes")
    @CrossOrigin(origins = "*")
    public List<Pass> findAllPasses() {
        return passRepository.findAllPasses();
    }

    @GetMapping("/api/find/pass/{passId}")
    public Pass findPassById (
            @PathVariable("passId") Integer passId) {
        return passRepository.findPassById(passId);
    }

    @GetMapping("/api/delete/pass/{passId}")
    public void deletePass(
            @PathVariable("passId") Integer id) {
        passRepository.deleteById(id);
    }

    @GetMapping("/api/update/pass/{passId}/")
    public Pass updatePass(
            @PathVariable("passId") Integer id) {
        Pass pass = passRepository.findPassById(id);
        return passRepository.save(pass);
    }
}
