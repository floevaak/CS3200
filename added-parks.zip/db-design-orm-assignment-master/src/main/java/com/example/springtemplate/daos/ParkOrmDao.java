package com.example.springtemplate.daos;

import com.example.springtemplate.models.Park;
import com.example.springtemplate.repositories.ParkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class ParkOrmDao {
    @Autowired
    ParkRepository parkRepository;

    @GetMapping("/api/create/park/{n}/{f}/{s}/{r}/{l}")
    public Park createPark(
            @PathVariable("n") String name,
            @PathVariable("f") Integer foodNum,
            @PathVariable("s") Integer sizeSqm,
            @PathVariable("r") Integer revenue,
            @PathVariable("l") Boolean lights) {
        Park park = new Park(name, foodNum, sizeSqm, revenue, lights);
        return parkRepository.save(park);
    }

    @GetMapping("/api/find/parks")
    public List<Park> findAllParks() {
        return parkRepository.findAllParks();
    }

    @GetMapping("/api/find/park/{parkId}")
    public Park findParkById (
            @PathVariable("parkId") Integer parkId) {
        return parkRepository.findParkById(parkId);
    }

    @GetMapping("/api/delete/park/{parkId}")
    public void deletePark(
            @PathVariable("parkId") Integer id) {
        parkRepository.deleteById(id);
    }

    @GetMapping("/api/update/park/{parkId}/")
    public Park updatePark(
            @PathVariable("parkId") Integer id) {
        Park park = parkRepository.findParkById(id);
        return parkRepository.save(park);
    }
}
