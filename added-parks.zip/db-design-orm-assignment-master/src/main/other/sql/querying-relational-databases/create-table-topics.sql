CREATE TABLE `db_design`.`topics` (
  `topic` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`topic`));
