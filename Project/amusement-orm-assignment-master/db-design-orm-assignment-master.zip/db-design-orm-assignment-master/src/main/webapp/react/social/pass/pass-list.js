const {Link, useHistory} = window.ReactRouterDOM;

import passService from "./pass-service"
const { useState, useEffect } = React;
const PassList = () => {
    const history = useHistory()
    const [passes, setPass] = useState([])
    useEffect(() => {
        findAllPasses()
    }, [])
    const findAllPasses = () =>
        passService.findAllPasses()
            .then(pass => setPass(pass))
    return(
        <div>
            <h2>Passes</h2>
            <button onClick={() => history.push("/passes/new")}>
                Add Pass
            </button>
            <ul className="list-group">
                {
                    passes.map(pass =>
                        <li key={pass.id}>
                            <Link to={`/passes/${pass.id}`}>
                                {pass.description},
                                 {pass.price},
                                 {pass.startDate},
                                 {pass.endDate}
                            </Link>
                        </li>)
                }
            </ul>
        </div>
    )
}

export default PassList;